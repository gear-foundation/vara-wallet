import type { Address, Hash, Hex } from 'viem';
/**
 * Stable string codes attached to every {@link VaraEthError}. Switch on these
 * (`err.code === VaraEthErrorCode.PromiseTimeout`) rather than `err.message`
 * — messages may change.
 */
export declare const VaraEthErrorCode: {
    readonly ViemForkRequired: "VIEM_FORK_REQUIRED";
    readonly InjectedTxStale: "INJECTED_TX_STALE";
    readonly PromiseTimeout: "PROMISE_TIMEOUT";
    readonly PromiseSigInvalid: "PROMISE_SIG_INVALID";
    readonly PermitExpired: "PERMIT_EXPIRED";
    readonly BlobUnderpriced: "BLOB_UNDERPRICED";
    readonly NoSailsIdl: "NO_SAILS_IDL";
    readonly RpcConnectionFailed: "RPC_CONNECTION_FAILED";
    readonly ChainIdMismatch: "CHAIN_ID_MISMATCH";
};
export type VaraEthErrorCode = (typeof VaraEthErrorCode)[keyof typeof VaraEthErrorCode];
/**
 * Base class for all typed errors thrown by `@vara-eth/api` public APIs.
 *
 * Sub-classes carry a stable {@link VaraEthErrorCode} for programmatic matching.
 * The `cause` chain is preserved when a typed error wraps an underlying viem /
 * JSON-RPC / network error.
 *
 * Sub-classes set `name` automatically via `new.target.name`.
 */
export declare class VaraEthError extends Error {
    readonly code: VaraEthErrorCode;
    constructor(code: VaraEthErrorCode, message: string, options?: {
        cause?: unknown;
    });
}
export declare class ViemForkRequiredError extends VaraEthError {
    constructor(cause?: unknown);
}
export declare class InjectedTxStaleError extends VaraEthError {
    constructor(referenceBlock: Hex, currentBlock: Hex, cause?: unknown);
}
export declare class PromiseTimeoutError extends VaraEthError {
    readonly txHash: Hash;
    constructor(txHash: Hash, timeoutMs: number, cause?: unknown);
}
export declare class PromiseSignatureInvalidError extends VaraEthError {
    /** Address recovered from the signature, if the recovery step itself succeeded. Undefined when recovery failed. */
    readonly recoveredAddress: Address | undefined;
    constructor(recoveredAddress: Address | undefined, cause?: unknown);
}
export declare class PermitExpiredError extends VaraEthError {
    constructor(deadline: bigint, now: bigint, cause?: unknown);
}
export declare class BlobUnderpricedError extends VaraEthError {
    constructor(maxFeePerBlobGas: bigint, baseFeePerBlobGas: bigint, cause?: unknown);
}
export declare class NoSailsIdlError extends VaraEthError {
    constructor();
}
export declare class RpcConnectionError extends VaraEthError {
    readonly endpoint?: string;
    constructor(endpoint: string | undefined, cause?: unknown);
}
export declare class ChainIdMismatchError extends VaraEthError {
    constructor(expected: number, got: number);
}

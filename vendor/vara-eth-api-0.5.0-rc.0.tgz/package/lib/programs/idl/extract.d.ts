/**
 * Sails IDL extraction from a Gear program WASM binary.
 *
 * Gear programs ship their Sails IDL as a WASM custom section named `sails_idl`
 * (or `sails-idl` — both casings are tolerated for forward-compat). This module
 * parses the WASM module structure just deeply enough to extract that section,
 * without instantiating or validating the code.
 *
 * Pure function, no side effects, no I/O.
 *
 * @example
 * ```ts
 * import { readFileSync } from 'node:fs';
 * import { extractSailsIdl } from '@vara-eth/api';
 *
 * const wasm = readFileSync('counter.opt.wasm');
 * const idl = extractSailsIdl(wasm);
 * if (idl) console.log(idl);
 * ```
 */
/**
 * Extracts the Sails IDL text from a Gear program WASM binary.
 *
 * @param wasm - The WASM module bytes (raw `.wasm` file contents)
 * @returns The IDL source as a UTF-8 string, or `null` if no `sails_idl` /
 *   `sails-idl` custom section is present. Returns `null` (not throw) on a
 *   truncated/malformed WASM — silent best-effort, since callers will fall back
 *   to opaque-payload mode.
 */
export declare function extractSailsIdl(wasm: Uint8Array): string | null;
/**
 * Strict variant of {@link extractSailsIdl} that throws {@link NoSailsIdlError}
 * when the section is missing. Use when an IDL is expected to be present and
 * its absence is a hard failure.
 */
export declare function extractSailsIdlOrThrow(wasm: Uint8Array): string;

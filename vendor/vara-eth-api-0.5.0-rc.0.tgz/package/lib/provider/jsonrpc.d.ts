import type { IJsonRpcMessage, IJsonRpcRequest, IJsonRpcResponseError, IJsonRpcResult, IJsonRpcSubscriptionMessage } from '../types/index.js';
export declare function createJsonRpcRequest(method: string, parameters: unknown[], id?: number): IJsonRpcRequest;
export declare function isErrorMessage(response: IJsonRpcMessage): response is IJsonRpcResponseError;
export declare function isResultMessage(response: IJsonRpcMessage): response is IJsonRpcResult;
export declare function isSubscriptionMessage(response: IJsonRpcMessage): response is IJsonRpcSubscriptionMessage;
export declare function getErrorMessage(response: IJsonRpcResponseError): string;

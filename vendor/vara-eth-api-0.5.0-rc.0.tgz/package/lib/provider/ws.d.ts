import type { ISubscriptionCallback, IVaraEthProvider, WsUrl } from '../types/index.js';
type ConnectionState = 'disconnected' | 'connecting' | 'connected' | 'failed';
export type ConnectionEventType = 'connecting' | 'connected' | 'disconnected' | 'error' | 'retry';
export type ConnectionEventListener = (event: {
    type: ConnectionEventType;
    error?: Error;
    attempt?: number;
    state?: ConnectionState;
    details?: Record<string, unknown>;
}) => void;
export interface ConnectionOptions {
    autoConnect?: boolean;
    reconnectAttempts?: number;
    reconnectDelay?: number;
    requestTimeout?: number;
}
export declare class WsVaraEthProvider implements IVaraEthProvider {
    private _conn?;
    private _state;
    private _nextId;
    private _pendingRequests;
    private _subscriptions;
    private _subscriptionIds;
    private _requestQueue;
    private _connectionPromise?;
    private _options;
    private _onOpen?;
    private _onError?;
    private _eventListeners;
    private _connectionStartTime?;
    private _url;
    constructor(url?: string, options?: ConnectionOptions);
    private _createRequest;
    private _setRequestTimeout;
    private _emitEvent;
    private _cleanupConnectionListeners;
    private _removeAllListeners;
    private _processQueue;
    private _rejectPendingRequests;
    private _setupPongHandler;
    private _onClose;
    private _onMessage;
    get isConnected(): boolean;
    get connectionState(): ConnectionState;
    get url(): WsUrl;
    connect(): Promise<void>;
    on(event: ConnectionEventType, listener: ConnectionEventListener): void;
    off(event: ConnectionEventType, listener?: ConnectionEventListener): void;
    private _attemptConnection;
    disconnect(): Promise<void>;
    send<Result = unknown>(method: string, parameters: unknown[], options?: {
        timeout?: number;
    }): Promise<Result>;
    subscribe<Error = unknown, Result = unknown>(method: string, unsubscribeMethod: string, parameters: unknown[], callback: ISubscriptionCallback<Error, Result>): Promise<() => void>;
    private unsubscribe;
}
export {};

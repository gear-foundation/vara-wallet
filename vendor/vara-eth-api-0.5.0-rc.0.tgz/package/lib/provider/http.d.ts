import type { IVaraEthProvider } from '../types/index.js';
type HttpUrl = `http://${string}` | `https://${string}`;
interface HttpOptions {
    requestTimeout?: number;
}
export declare class HttpVaraEthProvider implements IVaraEthProvider {
    private _url;
    private _options;
    constructor(_url?: HttpUrl, options?: HttpOptions);
    connect(): Promise<void>;
    disconnect(): Promise<void>;
    send<Result = unknown>(method: string, parameters: unknown[], options?: {
        timeout?: number;
    }): Promise<Result>;
    subscribe(): Promise<() => void>;
}
export {};

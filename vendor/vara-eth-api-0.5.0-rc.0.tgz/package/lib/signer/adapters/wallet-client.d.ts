import type { Address, Hash, Hex, TransactionRequest, WalletClient } from 'viem';
import type { ITransactionSigner, SignTypedDataParams } from '../../types/signer.js';
/**
 * Adapts a viem `WalletClient` to the {@link ITransactionSigner} interface.
 * Use {@link walletClientToSigner} as the preferred factory.
 */
export declare class WalletClientAdapter implements ITransactionSigner {
    private _wc;
    constructor(_wc: WalletClient);
    private get _account();
    signMessage(data: Uint8Array | string): Promise<Hash>;
    getAddress(): Promise<Address>;
    sendTransaction(tx: TransactionRequest): Promise<Hash>;
    signTypedData({ message, types, primaryType, domain }: SignTypedDataParams): Promise<Hex>;
}
/**
 * Creates a {@link WalletClientAdapter} from a viem `WalletClient`.
 *
 * @param walletClient - The viem wallet client to adapt
 * @returns A signer adapter wrapping the provided wallet client
 */
export declare function walletClientToSigner(walletClient: WalletClient): WalletClientAdapter;

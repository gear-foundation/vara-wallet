export declare class SigningError extends Error {
    constructor(message: string);
}
export declare class AddressError extends Error {
    constructor(message: string);
}

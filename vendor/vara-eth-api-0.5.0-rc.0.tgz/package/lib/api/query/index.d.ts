import { BlockQueries } from './block.js';
import { CodeQueries } from './code.js';
import { InjectedQueries } from './injected.js';
import { ProgramQueries } from './program.js';
export declare const query: {
    readonly block: typeof BlockQueries;
    readonly code: typeof CodeQueries;
    readonly program: typeof ProgramQueries;
    readonly injected: typeof InjectedQueries;
};
export type Query = {
    block: BlockQueries;
    code: CodeQueries;
    program: ProgramQueries;
    injected: InjectedQueries;
};

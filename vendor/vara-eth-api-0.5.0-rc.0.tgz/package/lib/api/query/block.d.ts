import type { BlockHeader, BlockRequestEvent, IVaraEthProvider, StateTransition } from '../../types/index.js';
export declare class BlockQueries {
    private _provider;
    constructor(_provider: IVaraEthProvider);
    header(hash?: string): Promise<BlockHeader>;
    events(hash?: string): Promise<BlockRequestEvent[]>;
    outcome(hash?: string): Promise<StateTransition[]>;
}

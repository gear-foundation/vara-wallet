import type { Hex } from 'viem';
import type { DispatchStash, FullProgramState, IVaraEthProvider, Mailbox, MemoryPages, MessageQueue, ProgramState, Waitlist } from '../../types/index.js';
export declare class ProgramQueries {
    private _provider;
    constructor(_provider: IVaraEthProvider);
    getIds(): Promise<Hex[]>;
    codeId(programId: string): Promise<Hex>;
    readState(hash: string): Promise<ProgramState>;
    readQueue(hash: string): Promise<MessageQueue>;
    readWaitlist(hash: string): Promise<Waitlist>;
    readStash(hash: string): Promise<DispatchStash>;
    readMailbox(hash: string): Promise<Mailbox>;
    readFullState(hash: string): Promise<FullProgramState>;
    readPages(hash: string): Promise<MemoryPages>;
    readPageData(hash: string): Promise<Hex>;
}

import type { Hex } from 'viem';
import type { IVaraEthProvider } from '../../types/index.js';
export declare class CodeQueries {
    private _provider;
    constructor(_provider: IVaraEthProvider);
    getOriginal(id: Hex): Promise<Hex>;
    getInstrumented(runtimeId: number, codeId: Hex): Promise<Hex>;
}

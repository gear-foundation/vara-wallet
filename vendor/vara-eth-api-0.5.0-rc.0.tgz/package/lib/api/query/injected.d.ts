import type { Address, Hash, Hex } from 'viem';
import type { IVaraEthProvider } from '../../types/index.js';
type InjectedTx = {
    data: {
        destination: Address;
        payload: Hex;
        value: number;
        referenceBlock: Hash;
        salt: Hash;
    };
    signature: Hex;
    address: Address;
};
export declare class InjectedQueries {
    private _provider;
    constructor(_provider: IVaraEthProvider);
    getTransaction(id: Hash): Promise<InjectedTx>;
    getTransactions(ids: Hash[]): Promise<(InjectedTx | null)[]>;
}
export {};

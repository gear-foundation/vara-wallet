import type { EthereumClient } from '../eth/index.js';
import type { IInjectedTransaction, IVaraEthProvider, IVaraEthValidatorPoolProvider } from '../types/index.js';
import { type Call } from './call/index.js';
import { FeesNamespace } from './fees/index.js';
import { InjectedTx } from './injected/index.js';
import { ProgramsNamespace } from './programs/index.js';
import { type Query } from './query/index.js';
import { StreamNamespace } from './stream/index.js';
export declare class VaraEthApi {
    private _ethClient?;
    private _provider;
    readonly query: Query;
    readonly call: Call;
    /**
     * High-level program operations: `deploy` and `sendAndWait`.
     * Available only when an {@link EthereumClient} is wired in (i.e. the api was
     * created via `createVaraEthApi`). Accessing a method when no EthereumClient
     * is set throws a clear error.
     */
    readonly programs: ProgramsNamespace;
    /**
     * Fee-estimation helpers.
     * Available only when an {@link EthereumClient} is wired in.
     */
    readonly fees: FeesNamespace;
    /**
     * Typed event streams over Router and Mirror contracts, plus block headers.
     * Available only when an {@link EthereumClient} is wired in.
     */
    readonly stream: StreamNamespace;
    constructor(provider: IVaraEthProvider | IVaraEthValidatorPoolProvider, _ethClient?: EthereumClient | undefined);
    private _setProps;
    get provider(): IVaraEthProvider | IVaraEthValidatorPoolProvider;
    get eth(): EthereumClient;
    createInjectedTransaction(tx: IInjectedTransaction): Promise<InjectedTx>;
}

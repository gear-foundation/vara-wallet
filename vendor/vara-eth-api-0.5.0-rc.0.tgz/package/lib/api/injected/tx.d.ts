import type { Address, Hash, Hex } from 'viem';
import type { EthereumClient } from '../../eth/index.js';
import type { IInjectedTransaction, IMessageSigner, IVaraEthProvider, IVaraEthValidatorPoolProvider } from '../../types/index.js';
import { InjectedTxPromise } from './promise.js';
export declare class InjectedTx {
    private _varaethProvider;
    private _ethClient;
    private _destination;
    private _payload;
    private _value;
    private _referenceBlock;
    private _salt;
    private _recipient?;
    private _signature;
    private _account;
    constructor(_varaethProvider: IVaraEthProvider | IVaraEthValidatorPoolProvider, _ethClient: EthereumClient, tx: IInjectedTransaction);
    private _trySetActiveValidator;
    get destination(): Hex;
    private get _destinationU8a();
    get recipient(): Address | null;
    get payload(): Hex;
    private get _payloadU8a();
    get value(): bigint;
    private get _valueU8a();
    get referenceBlock(): Hex | null;
    private get _referenceBlockU8a();
    get salt(): Hex;
    private get _saltU8a();
    private get _bytes();
    get hash(): Hex;
    get messageId(): Hex;
    get txHash(): Hex;
    private get _data();
    setValue(value: bigint): this;
    setSalt(value: Hex): this;
    setReferenceBlock(blockHash?: Hash): Promise<void>;
    /**
     * ## Specify validator address the transaction is intended for
     * @param address - (optional) the validator address. If omitted, defaults to the validator assigned to the current slot via {@link setSlotValidator}. Use {@link setDefaultValidator} to explicitly target no specific validator.
     * @returns the validator address
     */
    setRecipient(address?: Address): Promise<Address>;
    /**
     * ## Target the validator assigned to the current slot
     *
     * Computes the validator scheduled to process the imminent block using slot-based
     * round-robin (`floor(timestamp / blockDuration) % validators.length`), where the
     * timestamp is projected two blocks ahead to account for network propagation.
     *
     * Sets the computed address as the transaction {@link recipient}. If the provider is a
     * {@link IVaraEthValidatorPoolProvider | validator pool} and the address is present in the
     * pool, subsequent sends are routed directly to that validator's RPC connection. Otherwise
     * the transaction is forwarded by the receiving node.
     *
     * @returns The selected validator address
     */
    setSlotValidator(): Promise<`0x${string}`>;
    /** @deprecated Use {@link setSlotValidator} instead */
    setNextValidator(): Promise<`0x${string}`>;
    /**
     * ## Let any validator process the transaction
     *
     * Sets the recipient to the zero address, signalling that no specific validator is
     * targeted. The receiving node will include the transaction in the next available slot
     * regardless of which validator produces it.
     *
     * Use this when validator targeting is not important and you want the simplest, most
     * reliable delivery path.
     *
     * @returns The zero address
     */
    setDefaultValidator(): Address;
    private get _rpcData();
    /**
     * ## Sign the injected transaction
     * @returns The signature of the transaction
     */
    sign(signer?: IMessageSigner): Promise<`0x${string}`>;
    /**
     * ## Send the injected transaction
     */
    send(): Promise<string>;
    sendAndWaitForPromise(): Promise<InjectedTxPromise>;
}

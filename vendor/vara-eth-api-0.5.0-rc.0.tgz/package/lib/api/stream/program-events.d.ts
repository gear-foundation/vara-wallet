import type { Address, PublicClient } from 'viem';
import type { ProgramEvent, StreamHandlers, Unsubscribe } from './types.js';
/**
 * Options accepted by {@link watchProgramEvents}.
 */
export interface WatchProgramEventsOptions {
    /** Optional block number to start streaming from (back-fills historical logs). */
    fromBlock?: bigint;
}
/**
 * Subscribes to all events emitted by a Mirror contract and dispatches them
 * through a typed discriminated union.
 *
 * Wraps viem's `publicClient.watchContractEvent` — re-connection and polling
 * fallback are handled by viem internally.
 *
 * @param publicClient - viem PublicClient (typically `ethClient.publicClient`)
 * @param mirror - the Mirror contract address (per-program proxy)
 * @param handlers - {@link StreamHandlers}
 * @param options - {@link WatchProgramEventsOptions}
 * @returns {@link Unsubscribe} call this to stop the stream
 */
export declare function watchProgramEvents(publicClient: PublicClient, mirror: Address, handlers: StreamHandlers<ProgramEvent>, options?: WatchProgramEventsOptions): Unsubscribe;

import type { Address, PublicClient } from 'viem';
import type { RouterEvent, StreamHandlers, Unsubscribe } from './types.js';
/**
 * Options accepted by {@link watchRouterEvents}.
 */
export interface WatchRouterEventsOptions {
    /** Optional block number to start streaming from (back-fills historical logs). */
    fromBlock?: bigint;
}
/**
 * Subscribes to all events emitted by the Router contract and dispatches them
 * through a typed discriminated union.
 *
 * Wraps viem's `publicClient.watchContractEvent` — re-connection and polling
 * fallback are handled by viem internally.
 *
 * @param publicClient - viem PublicClient
 * @param router - the Router contract address (typically `ethClient.router.address`)
 * @param handlers - {@link StreamHandlers}
 * @param options - {@link WatchRouterEventsOptions}
 * @returns {@link Unsubscribe} call this to stop the stream
 */
export declare function watchRouterEvents(publicClient: PublicClient, router: Address, handlers: StreamHandlers<RouterEvent>, options?: WatchRouterEventsOptions): Unsubscribe;

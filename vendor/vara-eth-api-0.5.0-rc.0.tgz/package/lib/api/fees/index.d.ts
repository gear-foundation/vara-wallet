import type { EthereumClient } from '../../eth/index.js';
import { type FeeEstimate, type WalletOp } from './estimate.js';
export type { FeeEstimate, WalletOp } from './estimate.js';
export { estimateFee } from './estimate.js';
/**
 * Convenience namespace attached to {@link VaraEthApi} as `api.fees`.
 */
export declare class FeesNamespace {
    private readonly _ethClient;
    constructor(_ethClient: EthereumClient);
    /**
     * See {@link estimateFee}.
     */
    estimate(op: WalletOp): Promise<FeeEstimate>;
}

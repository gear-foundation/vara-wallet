import type { Address, Hex } from 'viem';
import type { EthereumClient } from '../../eth/index.js';
/**
 * Discriminated union of operations whose total cost can be estimated.
 */
export type WalletOp = {
    type: 'sendMessage';
    mirror: Address;
    payload: Hex;
    value?: bigint;
} | {
    type: 'sendReply';
    mirror: Address;
    repliedTo: Hex;
    payload: Hex;
    value?: bigint;
} | {
    type: 'claimValue';
    mirror: Address;
    claimedId: Hex;
} | {
    type: 'uploadCode';
    codeSize: number;
} | {
    type: 'createProgram';
    codeId: Hex;
};
/**
 * Estimated cost of a wallet-level operation.
 *
 * - `gas` is the viem-estimated gas limit for the on-chain transaction.
 * - `ethCostWei` is `gas * latestBaseFeePerGas` — a lower-bound floor; the real
 *   EIP-1559 tip is on top.
 * - `wvaraFee` is the program-level WVARA fee charged by the protocol (only
 *   present for `uploadCode`).
 *
 * For `uploadCode` the blob-fee component is NOT modelled here — callers
 * should budget ~2-3x ethCostWei headroom for the blob portion (varies with
 * `baseFeePerBlobGas`).
 */
export interface FeeEstimate {
    gas: bigint;
    ethCostWei: bigint;
    wvaraFee?: bigint;
}
/**
 * Estimates the total cost of a wallet operation before submitting it.
 */
export declare function estimateFee(ethClient: EthereumClient, op: WalletOp): Promise<FeeEstimate>;

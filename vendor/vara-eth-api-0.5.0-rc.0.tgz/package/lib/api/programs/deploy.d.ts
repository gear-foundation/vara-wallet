import type { Address, Hex, TransactionReceipt } from 'viem';
import type { EthereumClient } from '../../eth/index.js';
export interface DeployProgramOptions {
    /** Deterministic salt for the Mirror address. Random 32-byte hex if omitted. */
    salt?: Hex;
    /** Overrides the on-chain initializer (msg.sender by default). */
    overrideInitializer?: Address;
    /**
     * Solidity ABI interface contract address. When provided, the Mirror is
     * deployed in "non-small" form so Etherscan can decode calls.
     */
    abiInterface?: Address;
    /**
     * Initial WVARA executable balance to fund the Mirror with on deployment.
     * Requires a WVARA EIP-2612 permit signed by the signer; this helper signs
     * it automatically using the executable balance amount + a derived deadline.
     */
    executableBalance?: bigint;
    /**
     * EIP-2612 permit deadline override (Unix seconds). Defaults to `now + 5 min`.
     * Applied to both the code-validation fee permit and (if used) the executable
     * balance permit.
     */
    permitDeadline?: bigint;
}
export interface DeployProgramResult {
    /** blake2b-256 of the WASM bytecode. */
    codeId: Hex;
    /** Address of the newly created Mirror contract. */
    programAddress: Address;
    /** Ethereum receipt for the `requestCodeValidation` transaction. */
    codeValidationReceipt: TransactionReceipt;
    /** Ethereum receipt for the `createProgram*` transaction. */
    deploymentReceipt: TransactionReceipt;
}
/**
 * One-call helper that uploads a WASM, waits for validator approval, and
 * deploys a program from it. Replaces the multi-step ceremony of:
 *
 *   quote fee → sign WVARA permit → requestCodeValidation → wait for
 *   CodeGotValidated → (optional) sign executable-balance permit → build →
 *   wait for ProgramCreated.
 *
 * The optional executable-balance permit is signed in parallel with the
 * CodeGotValidated wait, hiding the local-signing round-trip behind chain
 * latency.
 *
 * The EthereumClient must already have a signer attached (set via the factory
 * or {@link EthereumClient.setSigner}). This helper does NOT take a signer
 * override to avoid mutating EthereumClient state mid-call.
 */
export declare function deployProgram(ethClient: EthereumClient, code: Uint8Array, options?: DeployProgramOptions): Promise<DeployProgramResult>;

import type { Hex } from 'viem';
import type { IVaraEthProvider, ReplyInfo } from '../../types/index.js';
export declare class ProgramCalls {
    private _provider;
    constructor(_provider: IVaraEthProvider);
    calculateReplyForHandle(source: string, programId: string, payload: Hex, value?: bigint): Promise<ReplyInfo>;
    calculateReplyForHandle(source: string, programId: string, payload: Hex, value: bigint, atBlock?: Hex): Promise<ReplyInfo>;
}

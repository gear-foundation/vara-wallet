import type { Abi, Address, ContractEventName, DecodeEventLogReturnType, Hash, PublicClient, TransactionReceipt, TransactionRequest } from 'viem';
import type { ITransactionSigner } from '../types/signer.js';
import type { ITxManager } from './interfaces/tx-manager.js';
/**
 * Manages Ethereum transactions with support for helper functions.
 * Provides utilities for handling transaction lifecycle, receipt retrieval,
 * and event processing.
 *
 * @template T - Type for transaction-dependent helper functions
 * @template U - Type for transaction-independent helper functions
 */
export declare class TxManager<T extends Record<string, any> = object, U extends Record<string, any> = object, const abi extends Abi = Abi> implements ITxManager {
    readonly pc: PublicClient;
    readonly signer: ITransactionSigner;
    private _tx;
    private _abi;
    private _receipt;
    private _hash;
    /**
     * Creates a new transaction manager.
     *
     * @param ethereumClient - The Ethereum client for sending transactions and reading data
     * @param _tx - The transaction request to manage
     * @param _abi - The ABI to use for parsing events
     * @param txDependentHelperFns - Helper functions that depend on the transaction
     * @param txIndependentHelperFns - Helper functions that do not depend on the transaction
     */
    constructor(pc: PublicClient, signer: ITransactionSigner, _tx: TransactionRequest, _abi: abi, txDependentHelperFns?: {
        [k in keyof T]: (manager: TxManager<T, U, abi>) => any;
    }, txIndependentHelperFns?: Record<keyof U, any>);
    /**
     * Estimates gas for the transaction and sets the gas limit.
     *
     * @returns The estimated gas limit as a bigint
     */
    estimateGas(): Promise<bigint>;
    /**
     * Sends the transaction to the network.
     *
     * @returns The transaction hash
     */
    send(): Promise<Hash>;
    /**
     * Sends the transaction and waits for the receipt.
     *
     * @returns The transaction receipt
     */
    sendAndWaitForReceipt(): Promise<TransactionReceipt>;
    /**
     * Gets the transaction receipt, waiting for it if necessary.
     *
     * @returns The transaction receipt
     */
    getReceipt(): Promise<TransactionReceipt>;
    /**
     * Finds a specific event in the transaction receipt.
     *
     * @param eventName - The name of the event to find
     * @returns The decoded event log with args
     * @throws Error if the event is not found in the transaction receipt
     */
    findEvent<eventName extends ContractEventName<abi>>(eventName: eventName): Promise<DecodeEventLogReturnType<abi, eventName>>;
    /**
     * Gets the transaction request.
     *
     * @returns The transaction request
     */
    getTx(): TransactionRequest;
    /**
     * Gets the block number of the transaction.
     *
     * @returns The block number or null if not available
     */
    get blockNumber(): bigint | null;
    get contractAddress(): Address;
}

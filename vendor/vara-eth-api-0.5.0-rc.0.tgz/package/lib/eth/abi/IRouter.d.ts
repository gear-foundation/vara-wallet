import type { Hex } from 'viem';
import type { CodeState } from '../interfaces/index.js';
export declare const IROUTER_ABI: readonly [{
    readonly type: "function";
    readonly name: "eip712Domain";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "fields";
        readonly type: "bytes1";
        readonly internalType: "bytes1";
    }, {
        readonly name: "name";
        readonly type: "string";
        readonly internalType: "string";
    }, {
        readonly name: "version";
        readonly type: "string";
        readonly internalType: "string";
    }, {
        readonly name: "chainId";
        readonly type: "uint256";
        readonly internalType: "uint256";
    }, {
        readonly name: "verifyingContract";
        readonly type: "address";
        readonly internalType: "address";
    }, {
        readonly name: "salt";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }, {
        readonly name: "extensions";
        readonly type: "uint256[]";
        readonly internalType: "uint256[]";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "event";
    readonly name: "EIP712DomainChanged";
    readonly inputs: readonly [];
    readonly anonymous: false;
}, {
    readonly type: "function";
    readonly name: "areValidators";
    readonly inputs: readonly [{
        readonly name: "_validators";
        readonly type: "address[]";
        readonly internalType: "address[]";
    }];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "bool";
        readonly internalType: "bool";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "codeState";
    readonly inputs: readonly [{
        readonly name: "_codeId";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "uint8";
        readonly internalType: "enum Gear.CodeState";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "codesStates";
    readonly inputs: readonly [{
        readonly name: "_codesIds";
        readonly type: "bytes32[]";
        readonly internalType: "bytes32[]";
    }];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "uint8[]";
        readonly internalType: "enum Gear.CodeState[]";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "commitBatch";
    readonly inputs: readonly [{
        readonly name: "_batch";
        readonly type: "tuple";
        readonly internalType: "struct Gear.BatchCommitment";
        readonly components: readonly [{
            readonly name: "blockHash";
            readonly type: "bytes32";
            readonly internalType: "bytes32";
        }, {
            readonly name: "blockTimestamp";
            readonly type: "uint48";
            readonly internalType: "uint48";
        }, {
            readonly name: "previousCommittedBatchHash";
            readonly type: "bytes32";
            readonly internalType: "bytes32";
        }, {
            readonly name: "expiry";
            readonly type: "uint8";
            readonly internalType: "uint8";
        }, {
            readonly name: "chainCommitment";
            readonly type: "tuple[]";
            readonly internalType: "struct Gear.ChainCommitment[]";
            readonly components: readonly [{
                readonly name: "transitions";
                readonly type: "tuple[]";
                readonly internalType: "struct Gear.StateTransition[]";
                readonly components: readonly [{
                    readonly name: "actorId";
                    readonly type: "address";
                    readonly internalType: "address";
                }, {
                    readonly name: "newStateHash";
                    readonly type: "bytes32";
                    readonly internalType: "bytes32";
                }, {
                    readonly name: "exited";
                    readonly type: "bool";
                    readonly internalType: "bool";
                }, {
                    readonly name: "inheritor";
                    readonly type: "address";
                    readonly internalType: "address";
                }, {
                    readonly name: "valueToReceive";
                    readonly type: "uint128";
                    readonly internalType: "uint128";
                }, {
                    readonly name: "valueToReceiveNegativeSign";
                    readonly type: "bool";
                    readonly internalType: "bool";
                }, {
                    readonly name: "valueClaims";
                    readonly type: "tuple[]";
                    readonly internalType: "struct Gear.ValueClaim[]";
                    readonly components: readonly [{
                        readonly name: "messageId";
                        readonly type: "bytes32";
                        readonly internalType: "bytes32";
                    }, {
                        readonly name: "destination";
                        readonly type: "address";
                        readonly internalType: "address";
                    }, {
                        readonly name: "value";
                        readonly type: "uint128";
                        readonly internalType: "uint128";
                    }];
                }, {
                    readonly name: "messages";
                    readonly type: "tuple[]";
                    readonly internalType: "struct Gear.Message[]";
                    readonly components: readonly [{
                        readonly name: "id";
                        readonly type: "bytes32";
                        readonly internalType: "bytes32";
                    }, {
                        readonly name: "destination";
                        readonly type: "address";
                        readonly internalType: "address";
                    }, {
                        readonly name: "payload";
                        readonly type: "bytes";
                        readonly internalType: "bytes";
                    }, {
                        readonly name: "value";
                        readonly type: "uint128";
                        readonly internalType: "uint128";
                    }, {
                        readonly name: "replyDetails";
                        readonly type: "tuple";
                        readonly internalType: "struct Gear.ReplyDetails";
                        readonly components: readonly [{
                            readonly name: "to";
                            readonly type: "bytes32";
                            readonly internalType: "bytes32";
                        }, {
                            readonly name: "code";
                            readonly type: "bytes4";
                            readonly internalType: "bytes4";
                        }];
                    }, {
                        readonly name: "call";
                        readonly type: "bool";
                        readonly internalType: "bool";
                    }];
                }];
            }, {
                readonly name: "head";
                readonly type: "bytes32";
                readonly internalType: "bytes32";
            }];
        }, {
            readonly name: "codeCommitments";
            readonly type: "tuple[]";
            readonly internalType: "struct Gear.CodeCommitment[]";
            readonly components: readonly [{
                readonly name: "id";
                readonly type: "bytes32";
                readonly internalType: "bytes32";
            }, {
                readonly name: "valid";
                readonly type: "bool";
                readonly internalType: "bool";
            }];
        }, {
            readonly name: "rewardsCommitment";
            readonly type: "tuple[]";
            readonly internalType: "struct Gear.RewardsCommitment[]";
            readonly components: readonly [{
                readonly name: "operators";
                readonly type: "tuple";
                readonly internalType: "struct Gear.OperatorRewardsCommitment";
                readonly components: readonly [{
                    readonly name: "amount";
                    readonly type: "uint256";
                    readonly internalType: "uint256";
                }, {
                    readonly name: "root";
                    readonly type: "bytes32";
                    readonly internalType: "bytes32";
                }];
            }, {
                readonly name: "stakers";
                readonly type: "tuple";
                readonly internalType: "struct Gear.StakerRewardsCommitment";
                readonly components: readonly [{
                    readonly name: "distribution";
                    readonly type: "tuple[]";
                    readonly internalType: "struct Gear.StakerRewards[]";
                    readonly components: readonly [{
                        readonly name: "vault";
                        readonly type: "address";
                        readonly internalType: "address";
                    }, {
                        readonly name: "amount";
                        readonly type: "uint256";
                        readonly internalType: "uint256";
                    }];
                }, {
                    readonly name: "totalAmount";
                    readonly type: "uint256";
                    readonly internalType: "uint256";
                }, {
                    readonly name: "token";
                    readonly type: "address";
                    readonly internalType: "address";
                }];
            }, {
                readonly name: "timestamp";
                readonly type: "uint48";
                readonly internalType: "uint48";
            }];
        }, {
            readonly name: "validatorsCommitment";
            readonly type: "tuple[]";
            readonly internalType: "struct Gear.ValidatorsCommitment[]";
            readonly components: readonly [{
                readonly name: "aggregatedPublicKey";
                readonly type: "tuple";
                readonly internalType: "struct Gear.AggregatedPublicKey";
                readonly components: readonly [{
                    readonly name: "x";
                    readonly type: "uint256";
                    readonly internalType: "uint256";
                }, {
                    readonly name: "y";
                    readonly type: "uint256";
                    readonly internalType: "uint256";
                }];
            }, {
                readonly name: "verifiableSecretSharingCommitment";
                readonly type: "bytes";
                readonly internalType: "bytes";
            }, {
                readonly name: "validators";
                readonly type: "address[]";
                readonly internalType: "address[]";
            }, {
                readonly name: "eraIndex";
                readonly type: "uint256";
                readonly internalType: "uint256";
            }];
        }];
    }, {
        readonly name: "_signatureType";
        readonly type: "uint8";
        readonly internalType: "enum Gear.SignatureType";
    }, {
        readonly name: "_signatures";
        readonly type: "bytes[]";
        readonly internalType: "bytes[]";
    }];
    readonly outputs: readonly [];
    readonly stateMutability: "nonpayable";
}, {
    readonly type: "function";
    readonly name: "computeSettings";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "tuple";
        readonly internalType: "struct Gear.ComputationSettings";
        readonly components: readonly [{
            readonly name: "threshold";
            readonly type: "uint64";
            readonly internalType: "uint64";
        }, {
            readonly name: "wvaraPerSecond";
            readonly type: "uint128";
            readonly internalType: "uint128";
        }];
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "createProgram";
    readonly inputs: readonly [{
        readonly name: "_codeId";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }, {
        readonly name: "_salt";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }, {
        readonly name: "_overrideInitializer";
        readonly type: "address";
        readonly internalType: "address";
    }];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "address";
        readonly internalType: "address";
    }];
    readonly stateMutability: "nonpayable";
}, {
    readonly type: "function";
    readonly name: "createProgramWithAbiInterface";
    readonly inputs: readonly [{
        readonly name: "_codeId";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }, {
        readonly name: "_salt";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }, {
        readonly name: "_overrideInitializer";
        readonly type: "address";
        readonly internalType: "address";
    }, {
        readonly name: "_abiInterface";
        readonly type: "address";
        readonly internalType: "address";
    }];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "address";
        readonly internalType: "address";
    }];
    readonly stateMutability: "nonpayable";
}, {
    readonly type: "function";
    readonly name: "createProgramWithAbiInterfaceAndExecutableBalance";
    readonly inputs: readonly [{
        readonly name: "_codeId";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }, {
        readonly name: "_salt";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }, {
        readonly name: "_overrideInitializer";
        readonly type: "address";
        readonly internalType: "address";
    }, {
        readonly name: "_abiInterface";
        readonly type: "address";
        readonly internalType: "address";
    }, {
        readonly name: "_initialExecutableBalance";
        readonly type: "uint128";
        readonly internalType: "uint128";
    }, {
        readonly name: "_deadline";
        readonly type: "uint256";
        readonly internalType: "uint256";
    }, {
        readonly name: "_v";
        readonly type: "uint8";
        readonly internalType: "uint8";
    }, {
        readonly name: "_r";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }, {
        readonly name: "_s";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "address";
        readonly internalType: "address";
    }];
    readonly stateMutability: "nonpayable";
}, {
    readonly type: "function";
    readonly name: "createProgramWithExecutableBalance";
    readonly inputs: readonly [{
        readonly name: "_codeId";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }, {
        readonly name: "_salt";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }, {
        readonly name: "_overrideInitializer";
        readonly type: "address";
        readonly internalType: "address";
    }, {
        readonly name: "_initialExecutableBalance";
        readonly type: "uint128";
        readonly internalType: "uint128";
    }, {
        readonly name: "_deadline";
        readonly type: "uint256";
        readonly internalType: "uint256";
    }, {
        readonly name: "_v";
        readonly type: "uint8";
        readonly internalType: "uint8";
    }, {
        readonly name: "_r";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }, {
        readonly name: "_s";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "address";
        readonly internalType: "address";
    }];
    readonly stateMutability: "nonpayable";
}, {
    readonly type: "function";
    readonly name: "genesisBlockHash";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "genesisTimestamp";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "uint48";
        readonly internalType: "uint48";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "isValidator";
    readonly inputs: readonly [{
        readonly name: "_validator";
        readonly type: "address";
        readonly internalType: "address";
    }];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "bool";
        readonly internalType: "bool";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "latestCommittedBatchHash";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "latestCommittedBatchTimestamp";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "uint48";
        readonly internalType: "uint48";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "middleware";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "address";
        readonly internalType: "address";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "mirrorImpl";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "address";
        readonly internalType: "address";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "nonces";
    readonly inputs: readonly [{
        readonly name: "owner";
        readonly type: "address";
        readonly internalType: "address";
    }];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "uint256";
        readonly internalType: "uint256";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "owner";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "address";
        readonly internalType: "address";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "paused";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "bool";
        readonly internalType: "bool";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "programCodeId";
    readonly inputs: readonly [{
        readonly name: "_programId";
        readonly type: "address";
        readonly internalType: "address";
    }];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "programsCodeIds";
    readonly inputs: readonly [{
        readonly name: "_programsIds";
        readonly type: "address[]";
        readonly internalType: "address[]";
    }];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "bytes32[]";
        readonly internalType: "bytes32[]";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "programsCount";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "uint256";
        readonly internalType: "uint256";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "proxiableUUID";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "requestCodeValidation";
    readonly inputs: readonly [{
        readonly name: "_codeId";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }, {
        readonly name: "_deadline";
        readonly type: "uint256";
        readonly internalType: "uint256";
    }, {
        readonly name: "_v";
        readonly type: "uint8";
        readonly internalType: "uint8";
    }, {
        readonly name: "_r";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }, {
        readonly name: "_s";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }];
    readonly outputs: readonly [];
    readonly stateMutability: "nonpayable";
}, {
    readonly type: "function";
    readonly name: "requestCodeValidationBaseFee";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "uint256";
        readonly internalType: "uint256";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "requestCodeValidationExtraFee";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "uint256";
        readonly internalType: "uint256";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "requestCodeValidationOnBehalf";
    readonly inputs: readonly [{
        readonly name: "_requester";
        readonly type: "address";
        readonly internalType: "address";
    }, {
        readonly name: "_codeId";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }, {
        readonly name: "_blobHashes";
        readonly type: "bytes32[]";
        readonly internalType: "bytes32[]";
    }, {
        readonly name: "_deadline";
        readonly type: "uint256";
        readonly internalType: "uint256";
    }, {
        readonly name: "_v1";
        readonly type: "uint8";
        readonly internalType: "uint8";
    }, {
        readonly name: "_r1";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }, {
        readonly name: "_s1";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }, {
        readonly name: "_v2";
        readonly type: "uint8";
        readonly internalType: "uint8";
    }, {
        readonly name: "_r2";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }, {
        readonly name: "_s2";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }];
    readonly outputs: readonly [];
    readonly stateMutability: "nonpayable";
}, {
    readonly type: "function";
    readonly name: "signingThresholdFraction";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "thresholdNumerator";
        readonly type: "uint128";
        readonly internalType: "uint128";
    }, {
        readonly name: "thresholdDenominator";
        readonly type: "uint128";
        readonly internalType: "uint128";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "timelines";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "tuple";
        readonly internalType: "struct Gear.Timelines";
        readonly components: readonly [{
            readonly name: "era";
            readonly type: "uint256";
            readonly internalType: "uint256";
        }, {
            readonly name: "election";
            readonly type: "uint256";
            readonly internalType: "uint256";
        }, {
            readonly name: "validationDelay";
            readonly type: "uint256";
            readonly internalType: "uint256";
        }];
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "validatedCodesCount";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "uint256";
        readonly internalType: "uint256";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "validators";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "address[]";
        readonly internalType: "address[]";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "validatorsAggregatedPublicKey";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "tuple";
        readonly internalType: "struct Gear.AggregatedPublicKey";
        readonly components: readonly [{
            readonly name: "x";
            readonly type: "uint256";
            readonly internalType: "uint256";
        }, {
            readonly name: "y";
            readonly type: "uint256";
            readonly internalType: "uint256";
        }];
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "validatorsCount";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "uint256";
        readonly internalType: "uint256";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "validatorsThreshold";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "uint256";
        readonly internalType: "uint256";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "validatorsVerifiableSecretSharingCommitment";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "bytes";
        readonly internalType: "bytes";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "function";
    readonly name: "wrappedVara";
    readonly inputs: readonly [];
    readonly outputs: readonly [{
        readonly name: "";
        readonly type: "address";
        readonly internalType: "address";
    }];
    readonly stateMutability: "view";
}, {
    readonly type: "event";
    readonly name: "AnnouncesCommitted";
    readonly inputs: readonly [{
        readonly name: "head";
        readonly type: "bytes32";
        readonly indexed: false;
        readonly internalType: "bytes32";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "BatchCommitted";
    readonly inputs: readonly [{
        readonly name: "hash";
        readonly type: "bytes32";
        readonly indexed: false;
        readonly internalType: "bytes32";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "CodeGotValidated";
    readonly inputs: readonly [{
        readonly name: "codeId";
        readonly type: "bytes32";
        readonly indexed: false;
        readonly internalType: "bytes32";
    }, {
        readonly name: "valid";
        readonly type: "bool";
        readonly indexed: true;
        readonly internalType: "bool";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "CodeValidationRequested";
    readonly inputs: readonly [{
        readonly name: "codeId";
        readonly type: "bytes32";
        readonly indexed: false;
        readonly internalType: "bytes32";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "ComputationSettingsChanged";
    readonly inputs: readonly [{
        readonly name: "threshold";
        readonly type: "uint64";
        readonly indexed: false;
        readonly internalType: "uint64";
    }, {
        readonly name: "wvaraPerSecond";
        readonly type: "uint128";
        readonly indexed: false;
        readonly internalType: "uint128";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "Initialized";
    readonly inputs: readonly [{
        readonly name: "version";
        readonly type: "uint64";
        readonly indexed: false;
        readonly internalType: "uint64";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "OwnershipTransferred";
    readonly inputs: readonly [{
        readonly name: "previousOwner";
        readonly type: "address";
        readonly indexed: true;
        readonly internalType: "address";
    }, {
        readonly name: "newOwner";
        readonly type: "address";
        readonly indexed: true;
        readonly internalType: "address";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "Paused";
    readonly inputs: readonly [{
        readonly name: "account";
        readonly type: "address";
        readonly indexed: false;
        readonly internalType: "address";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "ProgramCreated";
    readonly inputs: readonly [{
        readonly name: "actorId";
        readonly type: "address";
        readonly indexed: false;
        readonly internalType: "address";
    }, {
        readonly name: "codeId";
        readonly type: "bytes32";
        readonly indexed: true;
        readonly internalType: "bytes32";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "StorageSlotChanged";
    readonly inputs: readonly [{
        readonly name: "slot";
        readonly type: "bytes32";
        readonly indexed: false;
        readonly internalType: "bytes32";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "Unpaused";
    readonly inputs: readonly [{
        readonly name: "account";
        readonly type: "address";
        readonly indexed: false;
        readonly internalType: "address";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "Upgraded";
    readonly inputs: readonly [{
        readonly name: "implementation";
        readonly type: "address";
        readonly indexed: true;
        readonly internalType: "address";
    }];
    readonly anonymous: false;
}, {
    readonly type: "event";
    readonly name: "ValidatorsCommittedForEra";
    readonly inputs: readonly [{
        readonly name: "eraIndex";
        readonly type: "uint256";
        readonly indexed: false;
        readonly internalType: "uint256";
    }];
    readonly anonymous: false;
}, {
    readonly type: "error";
    readonly name: "AddressEmptyCode";
    readonly inputs: readonly [{
        readonly name: "target";
        readonly type: "address";
        readonly internalType: "address";
    }];
}, {
    readonly type: "error";
    readonly name: "ApproveERC20Failed";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "BatchTimestampNotInPast";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "BatchTimestampTooEarly";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "BlobNotFound";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "CodeAlreadyOnValidationOrValidated";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "CodeNotValidated";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "CodeValidationNotRequested";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "CommitmentEraNotNext";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "ECDSAInvalidSignature";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "ECDSAInvalidSignatureLength";
    readonly inputs: readonly [{
        readonly name: "length";
        readonly type: "uint256";
        readonly internalType: "uint256";
    }];
}, {
    readonly type: "error";
    readonly name: "ECDSAInvalidSignatureS";
    readonly inputs: readonly [{
        readonly name: "s";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }];
}, {
    readonly type: "error";
    readonly name: "ERC1967InvalidImplementation";
    readonly inputs: readonly [{
        readonly name: "implementation";
        readonly type: "address";
        readonly internalType: "address";
    }];
}, {
    readonly type: "error";
    readonly name: "ERC1967NonPayable";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "ElectionNotStarted";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "EmptyValidatorsList";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "EnforcedPause";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "EraDurationTooShort";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "ErasTimestampMustNotBeEqual";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "ExpectedPause";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "ExpiredSignature";
    readonly inputs: readonly [{
        readonly name: "deadline";
        readonly type: "uint256";
        readonly internalType: "uint256";
    }];
}, {
    readonly type: "error";
    readonly name: "FailedCall";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "GenesisHashAlreadySet";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "GenesisHashNotFound";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "InvalidBlobHash";
    readonly inputs: readonly [{
        readonly name: "index";
        readonly type: "uint256";
        readonly internalType: "uint256";
    }, {
        readonly name: "providedBlobHash";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }, {
        readonly name: "expectedBlobHash";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }];
}, {
    readonly type: "error";
    readonly name: "InvalidElectionDuration";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "InvalidFROSTAggregatedPublicKey";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "InvalidFrostSignatureCount";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "InvalidFrostSignatureLength";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "InvalidInitialization";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "InvalidPreviousCommittedBatchHash";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "InvalidSigner";
    readonly inputs: readonly [{
        readonly name: "signer";
        readonly type: "address";
        readonly internalType: "address";
    }, {
        readonly name: "requester";
        readonly type: "address";
        readonly internalType: "address";
    }];
}, {
    readonly type: "error";
    readonly name: "InvalidTimestamp";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "NotInitializing";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "OwnableInvalidOwner";
    readonly inputs: readonly [{
        readonly name: "owner";
        readonly type: "address";
        readonly internalType: "address";
    }];
}, {
    readonly type: "error";
    readonly name: "OwnableUnauthorizedAccount";
    readonly inputs: readonly [{
        readonly name: "account";
        readonly type: "address";
        readonly internalType: "address";
    }];
}, {
    readonly type: "error";
    readonly name: "PredecessorBlockNotFound";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "ReentrancyGuardReentrantCall";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "RewardsCommitmentEraNotPrevious";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "RewardsCommitmentPredatesGenesis";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "RewardsCommitmentTimestampNotInPast";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "RouterGenesisHashNotInitialized";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "SafeCastOverflowedUintDowncast";
    readonly inputs: readonly [{
        readonly name: "bits";
        readonly type: "uint8";
        readonly internalType: "uint8";
    }, {
        readonly name: "value";
        readonly type: "uint256";
        readonly internalType: "uint256";
    }];
}, {
    readonly type: "error";
    readonly name: "SignatureVerificationFailed";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "TimestampInFuture";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "TimestampOlderThanPreviousEra";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "TooManyChainCommitments";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "TooManyRewardsCommitments";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "TooManyValidatorsCommitments";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "TransferFromFailed";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "UUPSUnauthorizedCallContext";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "UUPSUnsupportedProxiableUUID";
    readonly inputs: readonly [{
        readonly name: "slot";
        readonly type: "bytes32";
        readonly internalType: "bytes32";
    }];
}, {
    readonly type: "error";
    readonly name: "UnknownProgram";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "ValidationBeforeGenesis";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "ValidationDelayTooBig";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "ValidatorsAlreadyScheduled";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "ValidatorsNotFoundForTimestamp";
    readonly inputs: readonly [];
}, {
    readonly type: "error";
    readonly name: "ZeroValueTransfer";
    readonly inputs: readonly [];
}];
/**
 * Interface for IRouter contract methods
 */
export interface IRouterContract {
    /**
     * Checks if all provided addresses are validators
     * @param validators - Array of validator addresses to check
     * @returns Promise resolving to true if all addresses are validators
     */
    areValidators(validators: string[]): Promise<boolean>;
    /**
     * Gets the validation state of a specific code
     * @param codeId - The ID of the code to check
     * @returns Promise resolving to the code state enum value
     */
    codeState(codeId: string): Promise<CodeState>;
    /**
     * Gets the validation states of multiple codes
     * @param codesIds - Array of code IDs to check
     * @returns Promise resolving to array of code state enum values
     */
    codesStates(codesIds: string[]): Promise<CodeState[]>;
    /**
     * Gets the current computation settings
     * @returns Promise resolving to computation settings with threshold and wVARA per second
     */
    computeSettings(): Promise<{
        threshold: bigint;
        wvaraPerSecond: bigint;
    }>;
    /**
     * Creates a new program with an ABI interface and value
     * @param codeId - The ID of the code to use
     * @param salt - Salt for address derivation
     * @param overrideInitializer - Optional initializer address override
     * @param abiInterface - The ABI interface address
     * @param value - Initial value for the program
     * @param deadline - Signature deadline
     * @param v - Signature v parameter
     * @param r - Signature r parameter
     * @param s - Signature s parameter
     * @returns Promise resolving to the new program address
     */
    /**
     * Gets the EIP-712 domain separator parameters
     */
    eip712Domain(): Promise<any>;
    /**
     * Gets the genesis block hash
     * @returns Promise resolving to the genesis block hash
     */
    genesisBlockHash(): Promise<string>;
    /**
     * Gets the genesis timestamp
     * @returns Promise resolving to the genesis timestamp
     */
    genesisTimestamp(): Promise<number>;
    /**
     * Checks if an address is a validator
     * @param validator - The address to check
     * @returns Promise resolving to true if the address is a validator
     */
    isValidator(validator: string): Promise<boolean>;
    /**
     * Gets the latest committed batch hash
     */
    latestCommittedBatchHash(): Promise<Hex>;
    /**
     * Gets the latest committed batch timestamp
     */
    latestCommittedBatchTimestamp(): Promise<number>;
    /**
     * Gets the middleware address
     */
    middleware(): Promise<string>;
    /**
     * Gets the mirror implementation address
     * @returns Promise resolving to the mirror implementation address
     */
    mirrorImpl(): Promise<string>;
    /**
     * Gets the owner address
     */
    owner(): Promise<string>;
    /**
     * Checks if the contract is paused
     */
    paused(): Promise<boolean>;
    /**
     * Gets the code ID for a specific program
     * @param programId - The program address to query
     * @returns Promise resolving to the code ID of the program
     */
    programCodeId(programId: string): Promise<string>;
    /**
     * Gets code IDs for multiple programs
     * @param programsIds - Array of program addresses to query
     * @returns Promise resolving to array of code IDs
     */
    programsCodeIds(programsIds: Hex[]): Promise<readonly Hex[]>;
    /**
     * Gets the total number of created programs
     * @returns Promise resolving to the programs count
     */
    programsCount(): Promise<bigint>;
    /**
     * Gets the base fee for code validation requests
     */
    requestCodeValidationBaseFee(): Promise<bigint>;
    /**
     * Gets the extra fee for code validation requests
     */
    requestCodeValidationExtraFee(): Promise<bigint>;
    /**
     * Gets the signing threshold fraction
     * @returns Promise resolving to the threshold percentage
     */
    signingThresholdFraction(): Promise<readonly [bigint, bigint]>;
    /**
     * Gets the timelines for eras and elections
     */
    timelines(): Promise<{
        era: bigint;
        election: bigint;
        validationDelay: bigint;
    }>;
    /**
     * Gets the count of validated codes
     * @returns Promise resolving to the number of validated codes
     */
    validatedCodesCount(): Promise<bigint>;
    /**
     * Gets the list of current validators
     * @returns Promise resolving to array of validator addresses
     */
    validators(): Promise<readonly Hex[]>;
    /**
     * Gets the aggregated public key of current validators
     * @returns Promise resolving to the aggregated public key structure
     */
    validatorsAggregatedPublicKey(): Promise<{
        x: bigint;
        y: bigint;
    }>;
    /**
     * Gets the total number of validators
     * @returns Promise resolving to the validators count
     */
    validatorsCount(): Promise<bigint>;
    /**
     * Gets the minimum number of validators required for consensus
     * @returns Promise resolving to the validators threshold
     */
    validatorsThreshold(): Promise<bigint>;
    /**
     * Gets the verifiable secret sharing commitment for validators
     * @returns Promise resolving to the VSS commitment bytes
     */
    validatorsVerifiableSecretSharingCommitment(): Promise<string>;
    /**
     * Gets the wrapped VARA token address
     * @returns Promise resolving to the wVARA token address
     */
    wrappedVara(): Promise<string>;
}

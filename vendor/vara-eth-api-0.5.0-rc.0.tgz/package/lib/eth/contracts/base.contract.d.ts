import type { Abi, Address, ContractFunctionArgs, ContractFunctionName, PublicClient, ReadContractReturnType } from 'viem';
import type { ITransactionSigner } from '../../types/signer.js';
export interface ContractClientParams<abi extends Abi = Abi> {
    /**
     * The contract address
     */
    address: Address;
    /**
     * Viem's PublicClient instance for reading contract data
     */
    publicClient: PublicClient;
    /**
     * The ABI of the contract
     */
    abi: abi;
    /**
     * (optional) Signer for signing and sending transactions
     */
    signer?: ITransactionSigner;
}
/** Abstract base class for all contract clients. Holds the address, public client, signer, and ABI. */
export declare abstract class BaseContractClient<const abi extends Abi> {
    /**
     * The contract address
     */
    readonly address: Address;
    protected _pc: PublicClient;
    protected _signer?: ITransactionSigner;
    protected _abi: abi;
    constructor(params: ContractClientParams<abi>);
    /**
     * Sets the signer used to sign and send transactions.
     * @param signer - Signer implementation
     * @returns `this` for chaining
     */
    setSigner(signer: ITransactionSigner): this;
    /**
     * Removes the current signer, making the client read-only.
     * @returns `this` for chaining
     */
    resetSigner(): this;
    /**
     * Returns the current signer, throwing if none is set.
     * @throws {Error} When no signer has been provided
     */
    protected _ensureSigner(): ITransactionSigner;
    /**
     * Calls a view or pure function on the contract.
     * @param functionName - ABI function name
     * @param args - Function arguments
     * @returns Decoded return value
     */
    protected read<functionName extends ContractFunctionName<abi, 'pure' | 'view'>, const args extends ContractFunctionArgs<abi, 'pure' | 'view', functionName>>(functionName: functionName, args?: args): Promise<ReadContractReturnType<abi, functionName, args>>;
}

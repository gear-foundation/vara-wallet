import type { Address, Hex, PublicClient, Signature } from 'viem';
import type { ITransactionSigner } from '../../types/signer.js';
import type { CreateProgramHelpers } from '../interfaces/router.js';
import type { TxManagerWithHelpers } from '../interfaces/tx-manager.js';
/**
 * Fluent builder for assembling a program-creation transaction.
 *
 * Use {@link RouterClient.createProgramBuilder} to obtain an instance — do not
 * construct this class directly.
 *
 * Call any combination of the `with*` setter methods, then call {@link build} to
 * produce a {@link TxManagerWithHelpers} ready to send. The correct on-chain
 * function is selected automatically:
 *
 * | `.withAbiInterface()` | `.withExecutableBalance()` | On-chain function |
 * |---|---|---|
 * | — | — | `createProgram` |
 * | ✓ | — | `createProgramWithAbiInterface` |
 * | — | ✓ | `createProgramWithExecutableBalance` |
 * | ✓ | ✓ | `createProgramWithAbiInterfaceAndExecutableBalance` |
 */
export declare class CreateProgramBuilder {
    private readonly _codeId;
    private readonly _pc;
    private readonly _getSigner;
    private readonly _contractAddress;
    private _salt?;
    private _overrideInitializer?;
    private _abiInterface?;
    private _executableBalance?;
    constructor(_codeId: Hex, _pc: PublicClient, _getSigner: () => ITransactionSigner, _contractAddress: Address);
    /**
     * Sets a deterministic salt for program address derivation.
     * When omitted, a random 32-byte salt is generated automatically.
     *
     * @param salt - 32-byte hex salt
     */
    withSalt(salt: Hex): this;
    /**
     * Overrides the initializer address. When omitted (or set to the zero address),
     * `msg.sender` is used as the initializer.
     *
     * @param address - Address to use as the initializer instead of `msg.sender`
     */
    withOverrideInitializer(address: Address): this;
    /**
     * Attaches a Solidity ABI interface contract to the deployed Mirror, enabling
     * Etherscan to display the program's ABI. Causes the Mirror to be deployed with
     * `isSmall = false`.
     *
     * @param address - Address of the deployed Solidity ABI contract
     */
    withAbiInterface(address: Address): this;
    /**
     * Funds the Mirror with an initial WVARA executable balance on deployment.
     * Uses an EIP-2612 permit signature so no prior `approve` call is required.
     * Obtain the signature via {@link WrappedVaraClient.prepareAndSignPermitData}.
     *
     * @param amount - Amount of WVARA to transfer to the Mirror as executable balance
     * @param deadline - Expiry timestamp for the WVARA permit signature
     * @param signature - EIP-712 permit signature authorising the WVARA transfer
     */
    withExecutableBalance(amount: bigint, deadline: bigint, signature: Signature | Hex): this;
    /**
     * Encodes the transaction and returns a transaction manager ready to send.
     * Automatically selects the correct on-chain function based on the configured options.
     *
     * @returns A transaction manager with a {@link CreateProgramHelpers.getProgramId | getProgramId} helper
     */
    build(): TxManagerWithHelpers<CreateProgramHelpers>;
}

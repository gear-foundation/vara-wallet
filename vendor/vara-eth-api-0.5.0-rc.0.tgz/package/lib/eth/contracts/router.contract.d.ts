import type { Address, Hash, Hex, Signature } from 'viem';
import { IROUTER_ABI, type IRouterContract } from '../abi/IRouter.js';
import { CodeState, type CodeValidationHelpers } from '../interfaces/router.js';
import type { TxManagerWithHelpers } from '../interfaces/tx-manager.js';
import type { ContractClientParams } from './base.contract.js';
import { CreateProgramBuilder } from './create-program.builder.js';
import { EIP712ContractClient } from './eip-712.contract.js';
/**
 * Constructor parameters for {@link RouterClient}.
 * Extends the base contract params with router-specific options.
 */
export type RouterContractClientParams = Omit<ContractClientParams, 'abi'> & {
    /**
     * Multiplier applied to the latest `baseFeePerBlobGas` to derive `maxFeePerBlobGas`
     * for EIP-4844 blob transactions. Defaults to `3n`.
     */
    maxFeePerBlobGasMultiplier?: bigint;
};
/**
 * Contract client for the Router contract.
 *
 * The Router is the primary entry point for a co-processor instance. It manages code validation,
 * program creation, batch commitment, and the validator set. It emits two types of events:
 * *informational* events that notify external users of changes, and *requesting* events that
 * instruct validator nodes to perform processing inside the co-processor.
 */
export declare class RouterClient extends EIP712ContractClient<typeof IROUTER_ABI> implements IRouterContract {
    private _cachedGenesisBlockHash;
    private _cachedGenesisTimestamp;
    private _cachedWrappedVara;
    private readonly _maxFeePerBlobGasMultiplier;
    constructor(params: RouterContractClientParams);
    /** Returns `true` if all provided addresses are current validators. */
    areValidators(validators: Address[]): Promise<boolean>;
    /**
     * Returns the validation state for each of the given code IDs.
     * @param codeIds - Array of code IDs (blake2b hashes of WASM bytecode)
     */
    codesStates(codeIds: Hex[]): Promise<CodeState[]>;
    /** Returns the current computation settings (gas threshold and WVARA-per-second rate). */
    computeSettings(): Promise<{
        threshold: bigint;
        wvaraPerSecond: bigint;
    }>;
    /**
     * Returns the hash of the genesis block that identifies this co-processor instance.
     * Result is fetched once and cached for subsequent calls.
     */
    genesisBlockHash(): Promise<Hash>;
    /**
     * Returns the timestamp of the genesis block.
     * Result is fetched once and cached for subsequent calls.
     */
    genesisTimestamp(): Promise<number>;
    /** Returns `true` if the given address is a current validator. */
    isValidator(validator: Address): Promise<boolean>;
    /** Returns the hash of the most recently committed batch. */
    latestCommittedBatchHash(): Promise<Hash>;
    /** Returns the timestamp of the most recently committed batch. */
    latestCommittedBatchTimestamp(): Promise<number>;
    /** Returns the address of the `Mirror` implementation contract used for proxy clones. */
    mirrorImpl(): Promise<string>;
    /** Returns the address of the middleware contract. */
    middleware(): Promise<string>;
    /** Returns the owner address of the Router contract. */
    owner(): Promise<string>;
    /** Returns `true` if the Router contract is currently paused. */
    paused(): Promise<boolean>;
    /** Returns the protocol timeline parameters (era duration, election duration, etc.). */
    timelines(): Promise<{
        era: bigint;
        election: bigint;
        validationDelay: bigint;
    }>;
    /**
     * Returns the code ID of the WASM implementation for the given program address.
     * @param programId - On-chain address of the Mirror (program)
     */
    programCodeId(programId: Address): Promise<string>;
    /**
     * Returns the code IDs for an array of program addresses.
     * @param programsIds - Array of on-chain Mirror (program) addresses
     */
    programsCodeIds(programsIds: Address[]): Promise<readonly Hex[]>;
    /** Returns the total number of programs created through this Router. */
    programsCount(): Promise<bigint>;
    /**
     * Returns the signing threshold as a fraction `[numerator, denominator]`.
     * A batch commitment is valid when at least `numerator/denominator` of validators sign it.
     */
    signingThresholdFraction(): Promise<readonly [bigint, bigint]>;
    /** Returns the total number of WASM codes that have been successfully validated. */
    validatedCodesCount(): Promise<bigint>;
    /** Returns the list of current validator addresses (lowercased). */
    validators(): Promise<Address[]>;
    /** Returns the aggregated FROST public key of the current validator set. */
    validatorsAggregatedPublicKey(): Promise<{
        x: bigint;
        y: bigint;
    }>;
    /** Returns the number of validators in the current set. */
    validatorsCount(): Promise<bigint>;
    /** Returns the minimum number of validator signatures required to commit a batch. */
    validatorsThreshold(): Promise<bigint>;
    /**
     * Returns the serialised FROST `VerifiableSecretSharingCommitment` for the current validator set.
     * See https://docs.rs/frost-core/latest/frost_core/keys/struct.VerifiableSecretSharingCommitment.html
     */
    validatorsVerifiableSecretSharingCommitment(): Promise<string>;
    /**
     * @returns The address of WrappedVara contract
     */
    wrappedVara(): Promise<Hex>;
    /**
     * Gets the validation state of a code.
     *
     * @param codeId - The ID of the code to check
     * @returns Promise resolving to the code state
     * @throws Error if the code state is invalid
     */
    codeState(codeId: Hex): Promise<CodeState>;
    /** Returns the base WVARA fee charged for `requestCodeValidation`. */
    requestCodeValidationBaseFee(): Promise<bigint>;
    /** Returns the extra WVARA fee charged on top of the base fee for `requestCodeValidationOnBehalf`. */
    requestCodeValidationExtraFee(): Promise<bigint>;
    /**
     * Returns the EIP-2612 permit nonce for the given owner address.
     * @param owner - Token holder address
     */
    nonces(owner: Address): Promise<bigint>;
    private _createRequestCodeValidationTxManager;
    /**
     * Requests code validation by submitting the code as a blob in the transaction.
     * Charges `requestCodeValidationBaseFee` in WVARA via an EIP-2612 permit,
     * so no prior `approve` call is needed.
     *
     * Note: `requestCodeValidationExtraFee` is NOT charged by this variant — it
     * applies only to {@link requestCodeValidationOnBehalf}, which transfers
     * `base + extra` to cover the gasless meta-tx surcharge.
     *
     * @param code - The WASM bytecode to be validated
     * @param deadline - Expiry timestamp for the WVARA permit signature
     * @param wvaraPermitSignature - EIP-712 permit signature authorising the fee transfer
     * @returns A transaction manager with validation-specific helper functions, including
     *          the code ID and a function to wait for the code to be validated
     */
    requestCodeValidation(code: Uint8Array, deadline: bigint, wvaraPermitSignature: Signature | Hex): Promise<TxManagerWithHelpers<CodeValidationHelpers>>;
    /**
     * Requests code validation on behalf of another address.
     * Charges `requestCodeValidationBaseFee + requestCodeValidationExtraFee` in WVARA.
     * Requires two EIP-712 signatures obtained from the requester via
     * {@link prepareAndSignRequestCodeValidationPermitData} and from the fee payer via
     * {@link WrappedVaraClient.prepareAndSignPermitData}.
     * @param requester - Address on whose behalf the request is made
     * @param code - The WASM bytecode to be validated
     * @param blobHashes - Blob hashes of the EIP-4844/EIP-7594 transaction sidecars
     * @param deadline - Shared expiry timestamp for both signatures
     * @param requestCodeValidationSignature - EIP-712 signature from the requester authorising the validation request
     * @param wvaraPermitSignature - EIP-712 permit signature authorising the WVARA fee transfer
     * @returns A transaction manager with validation-specific helper functions, including
     *          the code ID and a function to wait for the code to be validated
     */
    requestCodeValidationOnBehalf(requester: Address, code: Uint8Array, blobHashes: Hex[], deadline: bigint, requestCodeValidationSignature: Signature | Hex, wvaraPermitSignature: Signature | Hex): Promise<TxManagerWithHelpers<CodeValidationHelpers>>;
    prepareAndSignRequestCodeValidationPermitData(code: Uint8Array, deadline: bigint): Promise<{
        codeId: `0x${string}`;
        requester: `0x${string}`;
        blobHashes: `0x${string}`[];
        deadline: bigint;
        signature: `0x${string}`;
    }>;
    /**
     * Returns a fluent builder for creating a program from validated code.
     *
     * The builder selects the appropriate on-chain function automatically based on
     * which optional features are configured:
     *
     * | `.withAbiInterface()` | `.withExecutableBalance()` | On-chain function |
     * |---|---|---|
     * | — | — | `createProgram` |
     * | ✓ | — | `createProgramWithAbiInterface` |
     * | — | ✓ | `createProgramWithExecutableBalance` |
     * | ✓ | ✓ | `createProgramWithAbiInterfaceAndExecutableBalance` |
     *
     * @param codeId - The ID of the validated code to instantiate
     * @returns A {@link CreateProgramBuilder} instance
     *
     * @example Basic usage — create a program from validated code:
     * ```typescript
     * const tx = router.createProgramBuilder(codeId).build();
     * await tx.sendAndWaitForReceipt();
     * const programId = await tx.getProgramId();
     * ```
     *
     * @example With an Etherscan-compatible ABI interface:
     * ```typescript
     * const tx = router.createProgramBuilder(codeId)
     *   .withAbiInterface(abiContractAddress)
     *   .build();
     * await tx.sendAndWaitForReceipt();
     * ```
     *
     * @example With an initial WVARA executable balance (no ABI, gas-efficient Mirror):
     * ```typescript
     * const deadline = BigInt(Date.now() + 60_000);
     * const { signature } = await wvara.prepareAndSignPermitData(router.address, amount, deadline);
     *
     * const tx = router.createProgramBuilder(codeId)
     *   .withExecutableBalance(amount, deadline, signature)
     *   .build();
     * await tx.sendAndWaitForReceipt();
     * ```
     *
     * @example With both ABI interface and initial executable balance:
     * ```typescript
     * const deadline = BigInt(Date.now() + 60_000);
     * const { signature } = await wvara.prepareAndSignPermitData(router.address, amount, deadline);
     *
     * const tx = router.createProgramBuilder(codeId)
     *   .withAbiInterface(abiContractAddress)
     *   .withExecutableBalance(amount, deadline, signature)
     *   .build();
     * await tx.sendAndWaitForReceipt();
     * const programId = await tx.getProgramId();
     * ```
     *
     * @example With a deterministic address (salt) and custom initializer:
     * ```typescript
     * const tx = router.createProgramBuilder(codeId)
     *   .withSalt('0x' + '00'.repeat(32))
     *   .withOverrideInitializer(initializerAddress)
     *   .build();
     * await tx.sendAndWaitForReceipt();
     * ```
     */
    createProgramBuilder(codeId: Hex): CreateProgramBuilder;
}
/**
 * Creates a new RouterContract instance.
 *
 * @param params - {@link RouterContractClientParams} parameters for creating the Router contract client
 * @returns A new {@link RouterClient} instance that implements the {@link IRouterContract} interface
 */
export declare function getRouterClient(params: RouterContractClientParams): RouterClient;

import { type Address, type Hash } from 'viem';
import { IROUTER_ABI } from '../abi/IRouter.js';
import type { TxManager } from '../tx-manager.js';
type RouterTxManager = TxManager<object, object, typeof IROUTER_ABI>;
export declare const getProgramId: (manager: RouterTxManager) => () => Promise<string>;
export declare const waitForCodeGotValidated: (codeId: Hash) => (manager: RouterTxManager) => () => Promise<boolean>;
export declare const getSalt: (salt?: Hash) => `0x${string}`;
export declare const getOverrideInitializer: (overrideInitializer?: Address) => `0x${string}`;
export {};

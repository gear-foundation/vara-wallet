import { type Hex } from 'viem';
/**
 * Starts loading the KZG WASM library in the background.
 *
 * `kzg-wasm` is memory-intensive and is only needed when submitting EIP-4844 blob
 * transactions (i.e. code upload via `RouterClient.requestCodeValidation`). Without
 * this call, the module would be loaded eagerly at import time, consuming memory even
 * in applications that never use code upload.
 *
 * Call this once at application startup if your application uses code upload
 * functionality. This allows KZG initialization to proceed in parallel with other
 * setup work, so `waitForKzg` resolves immediately (or with minimal delay) when a
 * code upload is eventually triggered.
 *
 * If not called explicitly, loading begins lazily on the first call to `waitForKzg`.
 *
 * @example
 * import { initKzgLoading } from '@vara-eth/api/util';
 *
 * // Call once at startup, before any code upload operations
 * initKzgLoading();
 */
export declare const initKzgLoading: () => void;
export declare const waitForKzg: () => Promise<{
    loadTrustedSetup: (precompute?: number, trustedSetup?: import("kzg-wasm").TrustedSetup) => number;
    freeTrustedSetup: () => void;
    blobToKZGCommitment: (blob: string) => string;
    computeBlobKZGProof: (blob: string, commitment: string) => string;
    verifyBlobKZGProofBatch: (blobs: string[], commitments: string[], proofs: string[]) => boolean;
    verifyKZGProof: (commitment: string, z: string, y: string, proof: string) => boolean;
    verifyBlobKZGProof: (blob: string, commitment: string, proof: string) => boolean;
    computeCellsAndKZGProofs: (blob: string) => import("kzg-wasm").KZGProofWithCells;
    recoverCellsFromKZGProofs: (cellIndices: number[], partial_cells: string[], numCells: number) => import("kzg-wasm").KZGProofWithCells;
    verifyCellKZGProof: (commitment: string, cells: string[], proofs: string[]) => boolean;
    verifyCellKZGProofBatch: (commitments: string[], cellIndices: number[], cells: string[], proofs: string[], numCells: number) => boolean;
    verifyCellKzgProofBatch: (commitments: string[], cellIndices: number[], cells: string[], proofs: string[]) => boolean;
    recoverCellsAndProofs: (indices: number[], cells: string[]) => [string[], string[]];
    computeCells: (blob: string) => string[];
    computeCellsAndProofs: (blob: string) => [string[], string[]];
    verifyBlobProofBatch: (blobs: string[], commitments: string[], proofs: string[]) => boolean;
    computeBlobProof: (blob: string, commitment: string) => string;
    blobToKzgCommitment: (blob: string) => string;
    verifyProof: (commitment: string, z: string, y: string, proof: string) => boolean;
}>;
export declare const getKzg: () => {
    loadTrustedSetup: (precompute?: number, trustedSetup?: import("kzg-wasm").TrustedSetup) => number;
    freeTrustedSetup: () => void;
    blobToKZGCommitment: (blob: string) => string;
    computeBlobKZGProof: (blob: string, commitment: string) => string;
    verifyBlobKZGProofBatch: (blobs: string[], commitments: string[], proofs: string[]) => boolean;
    verifyKZGProof: (commitment: string, z: string, y: string, proof: string) => boolean;
    verifyBlobKZGProof: (blob: string, commitment: string, proof: string) => boolean;
    computeCellsAndKZGProofs: (blob: string) => import("kzg-wasm").KZGProofWithCells;
    recoverCellsFromKZGProofs: (cellIndices: number[], partial_cells: string[], numCells: number) => import("kzg-wasm").KZGProofWithCells;
    verifyCellKZGProof: (commitment: string, cells: string[], proofs: string[]) => boolean;
    verifyCellKZGProofBatch: (commitments: string[], cellIndices: number[], cells: string[], proofs: string[], numCells: number) => boolean;
    verifyCellKzgProofBatch: (commitments: string[], cellIndices: number[], cells: string[], proofs: string[]) => boolean;
    recoverCellsAndProofs: (indices: number[], cells: string[]) => [string[], string[]];
    computeCells: (blob: string) => string[];
    computeCellsAndProofs: (blob: string) => [string[], string[]];
    verifyBlobProofBatch: (blobs: string[], commitments: string[], proofs: string[]) => boolean;
    computeBlobProof: (blob: string, commitment: string) => string;
    blobToKzgCommitment: (blob: string) => string;
    verifyProof: (commitment: string, z: string, y: string, proof: string) => boolean;
};
export declare function simpleSidecarEncode(data: Uint8Array): Uint8Array[];
export declare function calculateBlobVersionedHashesAndCommitments(blobs: Uint8Array[]): {
    blobVersionedHashes: `0x${string}`[];
    blobCommitmentsMap: Map<`0x${string}`, `0x${string}`>;
};
export declare const computeBlobKzgProof: (blob: Uint8Array, commitment: Uint8Array) => import("viem").ByteArray;
export declare const computeCellsAndKzgProofs: (blob: Uint8Array) => [Uint8Array[], Uint8Array[]];
export declare const blobToKzgCommitment: (commitmentMap: Map<Hex, Hex>) => (blob: Uint8Array) => import("viem").ByteArray;

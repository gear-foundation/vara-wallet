export declare function bigint128ToBytes(value: bigint, littleEndian?: boolean): Uint8Array;

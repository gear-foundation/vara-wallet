export declare function normalizeDispatch(d: any): void;
export declare function normalizeStateTransition(t: any): void;
export declare function normalizeBlockEvent(e: any): void;

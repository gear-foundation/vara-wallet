import type { Abi } from 'viem';
/**
 * Decodes a revert error from a failed contract call (e.g. estimateGas, simulateContract).
 *
 * Tries each supplied ABI in order, then falls back to an empty ABI so that standard
 * Solidity built-ins (`Error(string)`, `Panic(uint256)`) are always decoded.
 * Returns a plain `Error` with a human-readable message so the caller can throw it.
 *
 * @param error - The raw error thrown by viem (EstimateGasExecutionError, etc.)
 * @param abis  - Contract ABIs to search for the error selector, in priority order
 */
export declare function decodeContractError(error: unknown, abis?: Abi[]): Error;

/**
 * Asserts at runtime that the installed `viem` is the `@vara-eth/viem` fork
 * with EIP-7594 multi-blob support. Called at the entry of code-upload paths
 * (`RouterClient.requestCodeValidation`,
 * `RouterClient.requestCodeValidationOnBehalf`,
 * `RouterClient.prepareAndSignRequestCodeValidationPermitData`).
 *
 * Read-only contract calls (`MirrorClient.stateHash`, `RouterClient.validators`,
 * etc.) never call this, so consumers who don't upload code can use upstream
 * viem freely.
 *
 * The probe is memoised — package.json is read once per process. In non-Node
 * runtimes the probe is skipped entirely (dApp bundles are responsible for
 * picking the right viem).
 *
 * @throws {ViemForkRequiredError} when the installed viem is not the fork.
 */
export declare function assertViemFork(): void;
/**
 * Test-only: reset the memoised probe result. Allows unit tests to exercise
 * both code paths.
 *
 * @internal
 */
export declare function _resetViemForkProbeCacheForTests(): void;

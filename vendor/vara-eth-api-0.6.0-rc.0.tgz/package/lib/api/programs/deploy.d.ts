import type { Address, Hex, TransactionReceipt } from 'viem';
import type { EthereumClient } from '../../eth/index.js';
export interface DeployProgramOptions {
    /** Deterministic salt for the Mirror address. Random 32-byte hex if omitted. */
    salt?: Hex;
    /** Overrides the on-chain initializer (msg.sender by default). */
    overrideInitializer?: Address;
    /**
     * Solidity ABI interface contract address. When provided, the Mirror is
     * deployed in "non-small" form so Etherscan can decode calls.
     */
    abiInterface?: Address;
    /**
     * Initial WVARA executable balance to fund the Mirror with on deployment.
     * Requires a WVARA EIP-2612 permit signed by the signer; this helper signs
     * it automatically using the executable balance amount + a derived deadline.
     */
    executableBalance?: bigint;
    /**
     * EIP-2612 permit deadline override (Unix seconds) used for BOTH the
     * code-validation fee permit and (if `executableBalance > 0`) the
     * executable-balance permit. Each permit is signed independently — the
     * code-fee permit at the start of the ceremony, the executable-balance
     * permit AFTER `CodeGotValidated` resolves — and each defaults to
     * `now + 5 min` if this override is omitted. Sharing one ABSOLUTE deadline
     * across both is only safe when the validator wait is short enough that
     * the executable-balance permit hasn't expired by the time `build()` runs.
     */
    permitDeadline?: bigint;
    /**
     * How long to wait for `CodeGotValidated` after the code-validation tx
     * commits. Defaults to 120s. On timeout, throws {@link CodeValidationTimeoutError}
     * carrying `codeId` + `txHash` so callers can resume the deploy by calling
     * `router.createProgramBuilder(codeId).build()` once validators commit
     * out-of-band.
     */
    codeValidationTimeoutMs?: number;
}
export interface DeployProgramResult {
    /** blake2b-256 of the WASM bytecode. */
    codeId: Hex;
    /** Address of the newly created Mirror contract. */
    programAddress: Address;
    /** Ethereum receipt for the `requestCodeValidation` transaction. */
    codeValidationReceipt: TransactionReceipt;
    /** Ethereum receipt for the `createProgram*` transaction. */
    deploymentReceipt: TransactionReceipt;
}
/**
 * One-call helper that uploads a WASM, waits for validator approval, and
 * deploys a program from it. Replaces the multi-step ceremony of:
 *
 *   quote fee → sign WVARA permit → requestCodeValidation → wait for
 *   CodeGotValidated → (optional) sign executable-balance permit → build →
 *   wait for ProgramCreated.
 *
 * The executable-balance permit is signed AFTER `CodeGotValidated` resolves
 * (not in parallel with the wait) so its deadline reflects a fresh `now` —
 * otherwise a long validator wait can expire the permit before `build()`
 * runs, silently reverting `createProgramWithExecutableBalance`.
 *
 * The EthereumClient must already have a signer attached (set via the factory
 * or {@link EthereumClient.setSigner}). This helper does NOT take a signer
 * override to avoid mutating EthereumClient state mid-call.
 */
export declare function deployProgram(ethClient: EthereumClient, code: Uint8Array, options?: DeployProgramOptions): Promise<DeployProgramResult>;

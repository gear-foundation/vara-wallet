import type { Address, Hex } from 'viem';
import { ReplyCode } from '../../errors/index.js';
import type { EthereumClient } from '../../eth/index.js';
import type { CreateInjectedTransaction } from './index.js';
/**
 * Path selector for {@link sendAndWaitForReply}.
 *
 * - `'eth'` (default): submit via Mirror.sendMessage on Ethereum L1. Caller pays ETH gas;
 *   reply is awaited via the on-chain Reply event listener.
 * - `'injected'`: submit via the ethexe-rpc `injected_sendTransactionAndWatch`.
 *   Caller pays no ETH gas (signer just signs); reply is awaited via the validator's
 *   signed promise envelope.
 */
export type SendPath = 'eth' | 'injected';
export interface SendAndWaitOptions {
    /** Which transport to use. Defaults to `'eth'` since it doesn't require validator routing. */
    via?: SendPath;
    /**
     * Value in wei. Honored only on `via: 'eth'`. The injected path REJECTS
     * non-zero value at the ethexe-rpc layer (see relay.rs) — pass any non-zero
     * value with `via: 'injected'` and this helper throws before signing.
     * The field is still part of the preimage on the injected path (signed as 0).
     */
    value?: bigint;
    /** Override the timeout for awaiting the reply. */
    timeoutMs?: number;
    /** For `via: 'injected'`: explicit reference block hash (defaults to recent head − 3). */
    referenceBlock?: Hex;
    /** For `via: 'injected'`: explicit salt (defaults to random 32 bytes). */
    salt?: Hex;
    /**
     * For `via: 'injected'`: explicit validator recipient. Defaults to the zero
     * address, which the ethexe-rpc relay interprets as "auto-route to the
     * next-slot producer" (see `relay.rs::route_transaction` →
     * `calculate_next_producer`). Not gossip-broadcast — the server picks one
     * validator deterministically from the slot calendar.
     */
    recipient?: Address;
    /**
     * For `via: 'injected'`: validate the validator's signature on the promise reply.
     * Defaults to `true`. Set to `false` only for diagnostics — turning this off in
     * production means accepting any validator's claim of having executed the tx.
     */
    validateSignature?: boolean;
}
/**
 * Shape of a resolved reply for either path.
 */
export interface ReplyResult {
    messageId: Hex;
    reply: {
        payload: Hex;
        value: bigint;
        code: ReplyCode;
    };
    /** Tx hash on Ethereum (eth path) or injected txHash (injected path). */
    txHash: Hex;
    /** Validator that signed the promise (injected path only). */
    validator?: Address;
}
/**
 * One-call helper: submit a message to a program and wait for its reply.
 * Supports both the on-chain Mirror.sendMessage path and the off-chain
 * injected-tx path. The choice belongs to the caller via {@link SendAndWaitOptions.via}.
 */
export declare function sendAndWaitForReply(createInjectedTransaction: CreateInjectedTransaction, ethClient: EthereumClient, mirror: Address, payload: Hex, options?: SendAndWaitOptions): Promise<ReplyResult>;

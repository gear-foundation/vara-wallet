import type { BlockHeader, BlockRequestEvent, IVaraEthProvider } from '../../types/index.js';
export declare class BlockQueries {
    private _provider;
    constructor(_provider: IVaraEthProvider);
    header(hash?: string): Promise<BlockHeader>;
    events(hash?: string): Promise<BlockRequestEvent[]>;
}

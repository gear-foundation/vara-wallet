export { InjectedTxPromise } from './promise.js';
export { InjectedTxReceipt, TransactionPurgedReason } from './receipt.js';
import { InjectedTx } from './tx.js';
/**
 * @deprecated use `InjectedTx` instead
 */
export declare const Injected: typeof InjectedTx;
/**
 * @deprecated use `InjectedTx` instead
 */
export type Injected = InjectedTx;
export { InjectedTx };
